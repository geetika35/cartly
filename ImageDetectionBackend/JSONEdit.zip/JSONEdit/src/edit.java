import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import org.apache.commons.io.IOUtils;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

public class edit {
	public static void main(String[] args) throws IOException {
		// Can insert args for more universal use in the resource section
		// May want to make a separate json file for each food cart location, otherwise
		// this will require further functionality to be added
		File in = new File("/home/gtandrews/Desktop/Location1/testJSON.json");
		InputStream inStream = new FileInputStream(in);
		String jsonTxt = IOUtils.toString(inStream);
		JsonObject js = new JsonParser().parse(jsonTxt).getAsJsonObject();
		// Add support for all food carts that have a trained cascade here
		switch (args[0]) {
			case "SaigonSandwich1":  
				js.remove("Saigon Sandwich");
				js.addProperty("Saigon Sandwich", 1);
				break;
			case "SaigonSandwich0":  
				js.remove("Saigon Sandwich");
				js.addProperty("Saigon Sandwich", 0);
				break;
			case "BatterBrothers1":
				js.remove("Batter Brothers");
				js.addProperty("Batter Brothers", 1);
				break;
			case "BatterBrothers0":
				js.remove("Batter Brothers");
				js.addProperty("Batter Brothers", 0);
				break;
			case "Banzo1":
				js.remove("Banzo");
				js.addProperty("Banzo", 1);
				break;
			case "Banzo0":
				js.remove("Banzo");
				js.addProperty("Banzo", 0);
				break;
			//case "StopSign1":
			//	js.remove("Stop Sign");
			//	js.addProperty("Stop Sign", 1);
			//	break;
			//case "StopSign0":
			//	js.remove("Stop Sign");
			//	js.addProperty("Stop Sign", 0);
			//	break;
			//case "HumanFace1":
			//	js.remove("Human Face");
			//	js.addProperty("Human Face", 1);
			//	break;
			//case "HumanFace0":
			//	js.remove("Human Face");
			//	js.addProperty("Human Face", 0);
			//	break;
		}
		JsonParser parse = new JsonParser();
		Gson gson = new GsonBuilder().setPrettyPrinting().create();
		JsonElement ele = parse.parse(js.toString());
		jsonTxt = gson.toJson(ele);
		// System.out.print(jsonTxt);
		// edit local path to the json file
		FileWriter fileOut = new FileWriter("/home/gtandrews/Desktop/Location1/testJSON.json");
		fileOut.write(jsonTxt);
		fileOut.close();
	}
}
