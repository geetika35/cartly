import os
os.system('./startSFTP.sh')
