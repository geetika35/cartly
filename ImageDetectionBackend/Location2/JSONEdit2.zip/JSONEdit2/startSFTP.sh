sshpass -p "PASSWORD" sftp gandrews@best-linux.cs.wisc.edu << !
	cd public
	cd html
	put testJSON.json
!
